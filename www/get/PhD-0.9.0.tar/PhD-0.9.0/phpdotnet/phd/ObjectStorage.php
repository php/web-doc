<?php
namespace phpdotnet\phd;
/* $Id: ObjectStorage.php 286561 2009-07-30 16:56:01Z bjori $ */

class ObjectStorage extends \SplObjectStorage
{
	protected static $r = array();

	public function attach($obj, $inf = array()) {
		if (!($obj instanceof Format)) {
			throw new InvalidArgumentException(
                'Only classess inheriting ' . __NAMESPACE__ . '\\Format supported'
            );
		}
		if (empty($inf)) {
			$inf = array(
				\XMLReader::ELEMENT => $obj->getElementMap(),
				\XMLReader::TEXT    => $obj->getTextMap(),
			);
		}
		parent::attach($obj, $inf);
		return $obj;
	}
	final protected static function setReader(Reader $r) {
		self::$r[] = $r;
	}
	final protected function getReader() {
		return end(self::$r);
	}
	final protected function popReader() {
		return array_pop(self::$r);
	}
}


/*
* vim600: sw=4 ts=4 syntax=php et
* vim<600: sw=4 ts=4
*/

