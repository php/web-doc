<?php
/*  $Id: PhDTheme.class.php,v 1.1.10.1 2008/11/07 22:16:42 cweiske Exp $ */

abstract class PhDTheme extends PhDHelper implements iPhDTheme {
    protected $format;
    public function registerFormat($format) {
        $this->format = $format;
        $this->format->registerTheme($this);
    }
}

interface iPhDTheme {
    public function appendData($data, $isChunk);
}

/*
 * vim600: sw=4 ts=4 fdm=syntax syntax=php et
 * vim<600: sw=4 ts=4
 */

