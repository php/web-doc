<?php
namespace phpdotnet\phd;
/* $Id: Interface.php 309879 2011-04-01 16:00:11Z rquadling $ */

interface Options_Interface {

    function optionList();

}

/*
 * vim600: sw=4 ts=4 syntax=php et
 * vim<600: sw=4 ts=4
 */
