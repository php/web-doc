<?php
/*  $Id: bightml.php,v 1.5 2007/11/05 19:49:04 bjori Exp $ */

require_once $ROOT . '/themes/php/phpdotnet.php';
class bightml extends phpdotnet implements PhDTheme {
    public function __construct(array $IDs, $filename, $ext = "html") {
        parent::__construct($IDs, $filename, $ext, false);
        $this->stream = fopen("bightml.html", "w");
        self::header();
    }
    public function appendData($data, $isChunk) {
        if($isChunk) {
            $data .= "<hr />";
        }
        return fwrite($this->stream, $data);
    }
    public function __destruct() {
        self::footer();
        fclose($this->stream);
    }
    public function header() {
        fwrite($this->stream, "<html><body>");
    }
    public function footer() {
        fwrite($this->stream, "</body></html>");
    }
    public function format_qandaset($open, $name, $attrs) {
        if ($open) {
            $this->tmp["qandaentry"] = array();
            $this->ostream = $this->stream;
            $this->stream = fopen("php://temp/maxmemory", "r+");
            return '';
        }

        $stream = $this->stream;
        $this->stream = $this->ostream;
        unset($this->ostream);
        rewind($stream);

        return parent::qandaset($stream);
    }
}


/*
 * vim600: sw=4 ts=4 fdm=syntax syntax=php et
 * vim<600: sw=4 ts=4
 */

