<?php
namespace phpdotnet\phd;
/* $Id$ */

interface Options_Interface {

    function optionList();

}

/*
 * vim600: sw=4 ts=4 syntax=php et
 * vim<600: sw=4 ts=4
 */
